//prog2.c

#include<stdio.h>
#include<stdlib.h>

int main(){
  
  printf("     |                                             |     \n"); 
  printf("     |                                             |     \n");
  printf("     |     ^^^^^^^^^^^            ^^^^^^^^^^^      |     \n");
  printf("     |     ^         ^            ^         ^      |     \n");
  printf("     |     ^         ^            ^         ^      |     \n");
  printf("     |     ^         ^            ^         ^      |     \n");
  
  exit(1); 
  
}
